package com.example.attandanceapp

import java.io.Serializable

data class Student(
    val id: Int,                      // Unique identifier for the student
    val name: String,                 // Name of the student
    var isPresent: Boolean = false    // Attendance status (default is false)
) : Serializable {
    // Additional functionality or utility methods can be added here
    fun toggleAttendance() {
        isPresent = !isPresent
    }
}
