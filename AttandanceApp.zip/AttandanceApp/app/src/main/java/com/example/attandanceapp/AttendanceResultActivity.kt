package com.example.attandanceapp

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AttendanceResultActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_attendance_result)

        val attendanceData = intent.getSerializableExtra("attendanceData") as ArrayList<Student>
        val resultTextView: TextView = findViewById(R.id.resultTextView)

        val presentStudents = attendanceData.filter { it.isPresent }.joinToString(", ") { it.name }
        resultTextView.text = if (presentStudents.isNotEmpty()) {
            "Present Students: $presentStudents"
        } else {
            "No students present."
        }
    }
}
