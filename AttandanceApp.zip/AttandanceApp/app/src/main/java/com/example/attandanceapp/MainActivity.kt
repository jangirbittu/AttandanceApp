package com.example.attandanceapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AttendanceAdapter
    private lateinit var students: MutableList<Student>
    private lateinit var searchField: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Sample data
        students = mutableListOf(
            Student(1, "Alice"),
            Student(2, "Bob"),
            Student(3, "Charlie"),
            Student(4, "David")
        )

        // Initialize UI components
        recyclerView = findViewById(R.id.recyclerView)
        searchField = findViewById(R.id.searchField)
        adapter = AttendanceAdapter(students) { student, isChecked ->
            // Handle attendance change
            student.isPresent = isChecked
        }
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Submit button
        findViewById<Button>(R.id.submitButton).setOnClickListener {
            val intent = Intent(this, AttendanceResultActivity::class.java)
            intent.putExtra("attendanceData", ArrayList(students))
            startActivity(intent)
        }

        // Search button
        findViewById<Button>(R.id.searchButton).setOnClickListener {
            val query = searchField.text.toString().trim()
            if (query.isNotEmpty()) {
                performSearch(query)
            } else {
                Toast.makeText(this, "Enter a name to search.", Toast.LENGTH_SHORT).show()
            }
        }

        // Reset button
        findViewById<Button>(R.id.resetButton).setOnClickListener {
            resetAttendance()
        }
    }

    private fun performSearch(query: String) {
        val filteredStudents = students.filter { it.name.contains(query, ignoreCase = true) }.toMutableList()

        if (filteredStudents.isNotEmpty()) {
            adapter.updateStudentList(filteredStudents)
        } else {
            Toast.makeText(this, "No students found with name '$query'.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun resetAttendance() {
        students.forEach { it.isPresent = false }
        adapter.notifyDataSetChanged()
        Toast.makeText(this, "Attendance has been reset.", Toast.LENGTH_SHORT).show()
    }
}
