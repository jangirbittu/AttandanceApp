package com.example.attandanceapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AttendanceAdapter(
    private var studentList: MutableList<Student>, // Mutable list to allow changes
    private val onStudentAttendanceChanged: (Student, Boolean) -> Unit // Callback for attendance changes
) : RecyclerView.Adapter<AttendanceAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val checkBox: CheckBox = itemView.findViewById(R.id.checkbox)
        private val textView: TextView = itemView.findViewById(R.id.studentName)

        fun bind(student: Student) {
            textView.text = student.name
            checkBox.isChecked = student.isPresent
            checkBox.setOnCheckedChangeListener { _, isChecked ->
                student.isPresent = isChecked
                onStudentAttendanceChanged(student, isChecked) // Notify parent of change
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_student, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(studentList[position])
    }

    override fun getItemCount(): Int = studentList.size

    // Update the student list dynamically
    fun updateStudentList(newList: MutableList<Student>) {
        studentList = newList
        notifyDataSetChanged() // Notify the adapter that data has changed
    }
}
